lst=list(map(int,input().split()))
st=[lst[-1]]
ans=[-1]
for i in range(len(lst)-2,-1,-1):
    if st[-1]<lst[i] and len(st)>0:
        while st[-1]<lst[i]:
            st.pop()
            if len(st)==0:
                break
        if len(st)>0:
            ans.append(st[-1])
            st.append(lst[i])

        else:
            ans.append(-1)
            st.append(lst[i])

    else:
        ans.append(st[-1])
        st.append(lst[i])

for i in range(len(ans)-1,-1,-1):
    print(ans[i],end=" ")

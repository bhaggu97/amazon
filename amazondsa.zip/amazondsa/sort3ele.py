class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class Linkedlist:
    def __init__(self):
        self.head=None
    def push(self,data):
        newnode=Node(data)
        newnode.next=self.head
        self.head=newnode
    def sortlist(self):
        zero = 0
        one = 0
        two = 0
        temp = llist.head
        while temp!= None:
            if temp.data == 0:
                zero += 1
            if temp.data == 1:
                one += 1
            if temp.data == 2:
                two += 1
            temp = temp.next
        temp=llist.head
        while True:
            if zero !=0:
                temp.data=0
                zero-=1
                temp=temp.next
            elif one !=0:
                temp.data=1
                one-=1
                temp=temp.next
            elif two !=0:
                temp.data=2
                two-=1
                temp=temp.next
            else:
                break
    def traverse(self):
        temp=self.head
        while(True):
            if temp.next==None:
                print(temp.data)
                break
            print(temp.data,end=",")
            temp=temp.next

llist=Linkedlist()
llist.push(0)
llist.push(1)
llist.push(2)
llist.push(0)
llist.push(1)
llist.push(1)
llist.traverse()
llist.sortlist()
llist.traverse()




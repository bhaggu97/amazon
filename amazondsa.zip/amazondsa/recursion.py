'''
#genrate all subsets or subsequesnse
def subset(i,lst,a):
    if i==len(lst):
        print(a)
        return
    else:
        a.append(lst[i])
        subset(i+1,lst,a)
        a.pop()
        subset(i+1,lst,a)
        return

lst=list(map(int,input().split()))
a=[]
i=0
subset(i,lst,a)
'''
'''#genrate all subsets or subsequesnse
def subset(i,lst,a,sum):
    if i==len(lst) and sum%3==0:
        print(a)
        return
    elif i== len(lst) and sum%3!=0:
        return
    else:
        a.append(lst[i])
        sum+=lst[i]
        subset(i+1,lst,a,sum)
        sum -= lst[i]
        a.pop()
        subset(i+1,lst,a,sum)
        return

lst=list(map(int,input().split()))
a=[]
i=0
sum=0
subset(i,lst,a,sum)'''
# pow of a number
'''def pow_(x,y):
    if y==1:
        return x
    if y%2==0:
        return pow_(x*x,y//2)
    if y%2!=0:
        return x*pow_(x*x,y//2)
x=int(input())
y=int(input())
print(pow_(x,y))'''
# insertion_sort
lst = list(map(int,input().split()))
def insertt(x):
    print("k",x)
    if len(lst)==0:
        lst.append(x)
        return
    if x>lst[-1]:
        lst.append(x)
        return
    else:
        y=lst.pop()
        insertt(x)
        lst.append(y)
def insertion(n):
    if n==0:
        return
    else:
        x=lst.pop()
        print(lst)
        insertion(n-1)
        print(lst)
        insertt(x)
n=len(lst)
insertion(n-1)
print(lst)

'''def knap(n,W):
    if n==0 or W==0:
        return 0
    if w[n-1]<=W:
        x=p[n-1]+knap(n-1,W-w[n-1])
        y=knap(n - 1, W)
        return max(x,y)
    else:
        return knap(n-1,W)

w=list(map(int,input().split()))
p=list(map(int,input().split()))
W=int(input())
n=len(w)
print(knap(n,W))'''
'''
n=int(input())
l=list(map(int,input().split(",")))
sum=0
for i in range(0,len(l)-1):
    if l[i]<l[i+1]:
        sum=sum+l[i+1]-l[i]
print(sum)
''''''
def rate(i,j,s):
    if len(s)==r+c-2:
        print(s)
        return
    x=s
    if i>0:
        s+="R"
        rate(i-1,j,s)
        s=x
    if j>0:
        s+="D"
        rate(i,j-1,s)
        s=x
r=int(input())
c=int(input())
rate(r-1,c-1,"")
'''
def rate(i,j,s):
    if len(s)==6:
        print(s)
        return
    if i<3:
        if mat[i+1][j]!=1:
            s+="D"
            rate(i+1,j,s)

    if j<3:
        if mat[i][j+1]!=1:
            s+="R"
            rate(i,j+1,s)

mat=[[0,1,1,1],[0,0,1,1],[0,0,1,1],[0,0,0,0]]
rate(0,0,"")
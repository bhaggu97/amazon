import csv
import datetime
def create():
    with open("assign.csv",'w') as obj:
        fobj=csv.writer(obj)
        fobj.writerow(['name','age','dob'])
        while True:
            name=input()
            age=input()
            dob=input()
            format='%d/%m/%Y'

            record=[name,age,datetime.datetime.strptime(dob,format).date()]
            fobj.writerow(record)
            ch=int(input())
            if ch==0:
                break
def display():
    with open("assign.csv",'r') as obj:
        fobj=csv.reader(obj)
        for i in fobj:
            print(i)
create()
display()


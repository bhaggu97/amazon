class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class Linkedlist:
    def __init__(self):
        self.head=None
    def push(self,data):
        newnode=Node(data)
        newnode.next=self.head
        self.head=newnode
    def remdup(self):
        temp=self.head
        while(temp.next!=None):
            if temp.data == temp.next.data:
                temp.next=temp.next.next
            else:
                temp=temp.next
    def traverse(self):
        temp=self.head
        while(True):
            if temp.next==None:
                print(temp.data)
                break
            print(temp.data,end=",")
            temp=temp.next

llist=Linkedlist()
for i in range(5):
    x=int(input())
    llist.push(x)
llist.remdup()
llist.traverse()
